#include <iostream>
#include <string>
#include "Grafo.h"


using namespace std;

void menuArbol() {
    cout << "\n--- SUBMENU ARBOL EN CONSTRUCCION ---\n";
    
    cout << "Volviendo al panel principal...\n";
}

void menuDigrafo() {
    cout << "\n--- SUBMENU DIGRAFO EN CONSTRUCCION ---\n";
    
    cout << "Volviendo al panel principal...\n";
}


void menuGrafo() {
    Grafo miGrafo("grafo.json");
    int opcion;
    string v1, v2;

    do {
        cout << "\n----------------------------------------\n";
        cout << "            SUBMENU: GRAFO              \n";
        cout << "----------------------------------------\n";
        cout << "1. Nuevo nodo\n";
        cout << "2. Eliminar nodo\n";
        cout << "3. Conectar nodos\n";
        cout << "4. Desconectar nodos\n";
        cout << "5. Ver grafo\n";
        cout << "6. Recorrido BFS\n";
        cout << "7. Recorrido DFS (Recursivo)\n";
        cout << "8. Verificar enlace (Recursivo)\n";
        cout << "9. Volver al panel principal\n";
        cout << "----------------------------------------\n";
        cout << "-- Selecciona una alternativa: ";

        if (!(cin >> opcion)) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Opcion no valida.\n";
            continue;
        }

        switch (opcion) {
            case 1:
                cout << "Nombre del nodo: ";
                cin >> v1;
                miGrafo.insertarVertice(v1);
                break;
            case 2:
                cout << "Nodo a borrar: ";
                cin >> v1;
                miGrafo.removerVertice(v1);
                break;
            case 3:
                cout << "Primer nodo (origen): ";
                cin >> v1;
                cout << "Segundo nodo (destino): ";
                cin >> v2;
                miGrafo.insertarEnlace(v1, v2);
                break;
            case 4:
                cout << "Primer nodo (origen): ";
                cin >> v1;
                cout << "Segundo nodo (destino): ";
                cin >> v2;
                miGrafo.removerEnlace(v1, v2);
                break;
            case 5:
                miGrafo.mostrarEstructura();
                break;
            case 6:
                cout << "Inicio de BFS: ";
                cin >> v1;
                miGrafo.recorridoAncho(v1);
                break;
            case 7:
                cout << "Inicio de DFS: ";
                cin >> v1;
                miGrafo.recorridoProfundo(v1);
                break;
            case 8:
                cout << "Pon el primer nodo: ";
                cin >> v1;
                cout << "Pon el segundo nodo: ";
                cin >> v2;
                
                // Aqu� se ejecuta nuestra nueva l�gica recursiva
                if (miGrafo.comprobarConexion(v1, v2)) {
                    cout << "<<" << v1 << " y " << v2 << " >> SI se encuentran enlazados.\n";
                } else {
                    cout << "<<" << v1 << " y " << v2 << " >> NO se encuentran enlazados.\n";
                }
                break;
            case 9:
                cout << "Saliendo del bloque de Grafos...\n";
                break;
            default:
                cout << "Alternativa incorrecta, intenta de nuevo.\n";
        }
    } while (opcion != 9);
}


int main() {
    int opcionEstructura;

    do {
        cout << "\n========================================\n";
        cout << "      SISTEMA DE ARBOL GRAFO Y DIGRAFO  \n";
        cout << "========================================\n";
        cout << "1. Usar Arbol\n";
        cout << "2. Usar Digrafo\n";
        cout << "3. Usar Grafo\n";
        cout << "4. Salir del programa\n";
        cout << "========================================\n";
        cout << "-- Selecciona una opcion (1-4): ";

        if (!(cin >> opcionEstructura)) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Seleccionar una de las 4 opciones existentes.\n";
            continue;
        }

        switch (opcionEstructura) {
            case 1:
                menuArbol();
                break;
            case 2:
                menuDigrafo();
                break;
            case 3:
                menuGrafo();
                break;
            case 4:
                cout << "\nSaliendo del programa.\n";
                break;
            default:
                cout << "Seleccionar una de las 4 opciones existentes.\n";
        }

    } while (opcionEstructura != 4);

    return 0;
}
