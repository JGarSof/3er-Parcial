#ifndef GRAFO_H
#define GRAFO_H

#include <string>
#include <vector>
#include <map>

class Grafo {
private:
    // Estructuras principales de datos
    std::map<std::string, std::vector<std::string>> mapaConexiones; 
    std::vector<std::string> registroVertices;                     
    std::string nombreDoc;                                         

   
    void registrarVerticeInternal(const std::string& v);
    void registrarEnlaceInternal(const std::string& a, const std::string& b);
    void ejecutarDfs(const std::string& v, std::map<std::string, bool>& marcas) const;
    void guardarDisco();
    void cargarDisco();

    
    bool comprobarConexionRecursiva(const std::string& actual, const std::string& destino, std::map<std::string, bool>& visitados) const;

public:
   
    Grafo(const std::string& archivoRuta = "grafo.json");

   
    bool existeVertice(const std::string& v) const;
    bool existeEnlace(const std::string& a, const std::string& b) const;

    
    void insertarVertice(const std::string& v);
    void removerVertice(const std::string& v);
    void insertarEnlace(const std::string& a, const std::string& b);
    void removerEnlace(const std::string& a, const std::string& b);

 
    void mostrarEstructura() const;
    void recorridoAncho(const std::string& origen) const;    // BFS (Iterativo con Cola)
    void recorridoProfundo(const std::string& origen) const;  // DFS (Recursivo interno)

   
    bool comprobarConexion(const std::string& a, const std::string& b) const;
};

#endif
