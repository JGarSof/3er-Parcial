#ifndef GRAFO_H
#define GRAFO_H

#include <string>
#include <vector>
#include <map>

class Grafo {
private:
    std::map<std::string, std::vector<std::string>> mapaConexiones;
    std::vector<std::string> registroVertices;
    std::string nombreDoc;

    void registrarVerticeInterno(const std::string& v);
    void registrarEnlaceInterno(const std::string& a, const std::string& b);
    void ejecutarDfs(const std::string& v, std::map<std::string, bool>& marcas) const;
    void guardarDisco();
    void cargarDisco();

public:
    Grafo(const std::string& archivoRuta = "grafo.json");

    bool existeVertice(const std::string& v) const;
    bool existeEnlace(const std::string& a, const std::string& b) const;

    void insertarVertice(const std::string& v);
    void removerVertice(const std::string& v);

    void insertarEnlace(const std::string& a, const std::string& b);
    void removerEnlace(const std::string& a, const std::string& b);

    void mostrarEstructura() const;

    void recorridoAncho(const std::string& origen) const; // BFS
    void recorridoProfundo(const std::string& origen) const; // DFS

    bool comprobarConexion(const std::string& a, const std::string& b) const;
};

#endif