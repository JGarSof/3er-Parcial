#ifndef ARBOL_H
#define ARBOL_H

#include <string>
#include <vector>

struct ElementoArbol {
    std::string dato;
    ElementoArbol* hijoIzq;
    ElementoArbol* hijoDer;

    ElementoArbol(const std::string& d) : dato(d), hijoIzq(nullptr), hijoDer(nullptr) {}
};

class Arbol {
private:
    ElementoArbol* nodoRaiz;
    std::string rutaArchivo;

    ElementoArbol* agregarAux(ElementoArbol* actual, const std::string& info, bool& exito);
    ElementoArbol* quitarAux(ElementoArbol* actual, const std::string& info, bool& exito);
    bool rastrearAux(ElementoArbol* actual, const std::string& info) const;
    ElementoArbol* buscarMasPequeno(ElementoArbol* actual) const;
    void destruirEstructura(ElementoArbol* actual);

    bool esValorNumerico(const std::string& texto) const;
    int evaluarCruce(const std::string& val1, const std::string& val2) const;

    void preOrdenAux(ElementoArbol* actual, std::vector<std::string>& recolector) const;
    void inOrdenAux(ElementoArbol* actual, std::vector<std::string>& recolector) const;
    void postOrdenAux(ElementoArbol* actual, std::vector<std::string>& recolector) const;

    void respaldarEnDisco();
    void restaurarDeDisco();
    void mostrarArreglo(const std::vector<std::string>& arreglo) const;

public:
    Arbol(const std::string& archivoNom = "datos_arbol.json");
    ~Arbol();

    void agregarDato(const std::string& info);
    void quitarDato(const std::string& info);
    bool existeDato(const std::string& info) const;

    void imprimirPreOrden() const;
    void imprimirInOrden() const;
    void imprimirPostOrden() const;
};

#endif