#include "Arbol.h"
#include <iostream>
#include <fstream>

using namespace std;

Arbol::Arbol(const string& archivoNom) {
    nodoRaiz = nullptr;
    rutaArchivo = archivoNom;
    restaurarDeDisco();
}

bool Arbol::esValorNumerico(const string& texto) const {
    if (texto.empty()) return false;
    try {
        size_t indice;
        stod(texto, &indice);
        return indice == texto.size(); 
    } catch (...) {
        return false;
    }
}

int Arbol::evaluarCruce(const string& val1, const string& val2) const {
    if (esValorNumerico(val1) && esValorNumerico(val2)) {
        double num1 = stod(val1);
        double num2 = stod(val2);
        if (num1 < num2) return -1;
        if (num1 > num2) return 1;
        return 0;
    } else {
        if (val1 < val2) return -1;
        if (val1 > val2) return 1;
        return 0;
    }
}

Arbol::~Arbol() {
    destruirEstructura(nodoRaiz);
}

void Arbol::destruirEstructura(ElementoArbol* actual) {
    if (actual == nullptr) return;
    destruirEstructura(actual->hijoIzq);
    destruirEstructura(actual->hijoDer);
    delete actual;
}

ElementoArbol* Arbol::agregarAux(ElementoArbol* actual, const string& info, bool& exito) {
    if (actual == nullptr) {
        exito = true;
        return new ElementoArbol(info);
    }

    int resultado = evaluarCruce(info, actual->dato);
    if (resultado < 0) {
        actual->hijoIzq = agregarAux(actual->hijoIzq, info, exito);
    } else if (resultado > 0) {
        actual->hijoDer = agregarAux(actual->hijoDer, info, exito);
    } else {
        exito = false; 
    }

    return actual;
}

void Arbol::agregarDato(const string& info) {
    bool exito = false;
    nodoRaiz = agregarAux(nodoRaiz, info, exito);

    if (exito) {
        respaldarEnDisco();
        cout << "Listo, '" << info << "' se guardo en el arbol.\n";
    } else {
        cout << "Ese dato '" << info << "' ya lo habias metido antes.\n";
    }
}

ElementoArbol* Arbol::buscarMasPequeno(ElementoArbol* actual) const {
    while (actual->hijoIzq != nullptr) {
        actual = actual->hijoIzq;
    }
    return actual;
}

ElementoArbol* Arbol::quitarAux(ElementoArbol* actual, const string& info, bool& exito) {
    if (actual == nullptr) {
        exito = false;
        return nullptr;
    }

    int resultado = evaluarCruce(info, actual->dato);
    if (resultado < 0) {
        actual->hijoIzq = quitarAux(actual->hijoIzq, info, exito);
    } else if (resultado > 0) {
        actual->hijoDer = quitarAux(actual->hijoDer, info, exito);
    } else {
        exito = true;

        if (actual->hijoIzq == nullptr) {
            ElementoArbol* temporal = actual->hijoDer;
            delete actual;
            return temporal;
        } else if (actual->hijoDer == nullptr) {
            ElementoArbol* temporal = actual->hijoIzq;
            delete actual;
            return temporal;
        }

        ElementoArbol* relevo = buscarMasPequeno(actual->hijoDer);
        actual->dato = relevo->dato;
        bool banderaAuxiliar;
        actual->hijoDer = quitarAux(actual->hijoDer, relevo->dato, banderaAuxiliar);
    }

    return actual;
}

void Arbol::quitarDato(const string& info) {
    bool exito = false;
    nodoRaiz = quitarAux(nodoRaiz, info, exito);

    if (exito) {
        respaldarEnDisco();
        cout << "Se borro '" << info << "' del arbol.\n";
    } else {
        cout << "Ni busque, '" << info << "' no existe en este arbol.\n";
    }
}

bool Arbol::rastrearAux(ElementoArbol* actual, const string& info) const {
    if (actual == nullptr) return false;

    int resultado = evaluarCruce(info, actual->dato);
    if (resultado == 0) return true;

    if (resultado < 0) {
        return rastrearAux(actual->hijoIzq, info);
    } else {
        return rastrearAux(actual->hijoDer, info);
    }
}

bool Arbol::existeDato(const string& info) const {
    return rastrearAux(nodoRaiz, info);
}

void Arbol::preOrdenAux(ElementoArbol* actual, vector<string>& recolector) const {
    if (actual == nullptr) return;
    recolector.push_back(actual->dato);
    preOrdenAux(actual->hijoIzq, recolector);
    preOrdenAux(actual->hijoDer, recolector);
}

void Arbol::inOrdenAux(ElementoArbol* actual, vector<string>& recolector) const {
    if (actual == nullptr) return;
    inOrdenAux(actual->hijoIzq, recolector);
    recolector.push_back(actual->dato);
    inOrdenAux(actual->hijoDer, recolector);
}

void Arbol::postOrdenAux(ElementoArbol* actual, vector<string>& recolector) const {
    if (actual == nullptr) return;
    postOrdenAux(actual->hijoIzq, recolector);
    postOrdenAux(actual->hijoDer, recolector);
    recolector.push_back(actual->dato);
}

void Arbol::mostrarArreglo(const vector<string>& arreglo) const {
    if (arreglo.empty()) {
        cout << "(no hay nada)";
    } else {
        for (size_t i = 0; i < arreglo.size(); i++) {
            cout << arreglo[i] << (i < arreglo.size() - 1 ? " - " : "");
        }
    }
    cout << "\n";
}

void Arbol::imprimirPreOrden() const {
    vector<string> buffer;
    preOrdenAux(nodoRaiz, buffer);
    cout << ">> Ruta Pre-orden: ";
    mostrarArreglo(buffer);
}

void Arbol::imprimirInOrden() const {
    vector<string> buffer;
    inOrdenAux(nodoRaiz, buffer);
    cout << ">> Ruta In-orden: ";
    mostrarArreglo(buffer);
}

void Arbol::imprimirPostOrden() const {
    vector<string> buffer;
    postOrdenAux(nodoRaiz, buffer);
    cout << ">> Ruta Post-orden: ";
    mostrarArreglo(buffer);
}

void Arbol::respaldarEnDisco() {
    vector<string> buffer;
    preOrdenAux(nodoRaiz, buffer);

    ofstream salida(rutaArchivo);
    salida << "{\n";
    salida << "  \"elementos\": [\n";
    for (size_t i = 0; i < buffer.size(); i++) {
        salida << "    \"" << buffer[i] << "\"";
        if (i != buffer.size() - 1) salida << ",";
        salida << "\n";
    }
    salida << "  ]\n";
    salida << "}\n";
    salida.close();
}

void Arbol::restaurarDeDisco() {
    ifstream entrada(rutaArchivo);
    if (!entrada.is_open()) return;

    string contenido((istreambuf_iterator<char>(entrada)), istreambuf_iterator<char>());
    entrada.close();

    bool enComillas = false;
    bool enArreglo = false;
    string cadenaActual = "";

    for (char c : contenido) {
        if (c == '"') {
            enComillas = !enComillas;
            if (!enComillas) {
                if (enArreglo && cadenaActual != "elementos") {
                    bool indicador;
                    nodoRaiz = agregarAux(nodoRaiz, cadenaActual, indicador);
                }
                cadenaActual = "";
            }
            continue;
        }
        if (enComillas) {
            cadenaActual += c;
            continue;
        }
        if (c == '[') enArreglo = true;
        if (c == ']') enArreglo = false;
    }
}