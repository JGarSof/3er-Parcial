#include "Grafo.h"
#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>

using namespace std;

Grafo::Grafo(const string& archivoRuta) : nombreDoc(archivoRuta) {
    cargarDisco();
}

void Grafo::registrarVerticeInterno(const string& v) {
    if (mapaConexiones.find(v) == mapaConexiones.end()) {
        mapaConexiones[v] = vector<string>();
        registroVertices.push_back(v);
    }
}

void Grafo::registrarEnlaceInterno(const string& a, const string& b) {
    registrarVerticeInterno(a);
    registrarVerticeInterno(b);

    if (existeEnlace(a, b)) return;

    mapaConexiones[a].push_back(b);
    mapaConexiones[b].push_back(a);
}

bool Grafo::existeVertice(const string& v) const {
    return mapaConexiones.find(v) != mapaConexiones.end();
}

bool Grafo::existeEnlace(const string& a, const string& b) const {
    if (!existeVertice(a)) return false;
    const vector<string>& lista = mapaConexiones.at(a);
    return find(lista.begin(), lista.end(), b) != lista.end();
}

void Grafo::insertarVertice(const string& v) {
    if (existeVertice(v)) {
        cout << "Ese vertice ya esta agregado.\n";
        return;
    }
    registrarVerticeInterno(v);
    guardarDisco();
    cout << "Listo, vertice '" << v << "' agregado.\n";
}

void Grafo::removerVertice(const string& v) {
    if (!existeVertice(v)) {
        cout << "Ese vertice ni existe.\n";
        return;
    }

    for (auto& par : mapaConexiones) {
        auto& lista = par.second;
        lista.erase(remove(lista.begin(), lista.end(), v), lista.end());
    }

    mapaConexiones.erase(v);
    registroVertices.erase(remove(registroVertices.begin(), registroVertices.end(), v), registroVertices.end());

    guardarDisco();
    cout << "Vertice '" << v << "' borrado por completo.\n";
}

void Grafo::insertarEnlace(const string& a, const string& b) {
    if (existeEnlace(a, b)) {
        cout << "La conexion entre " << a << " y " << b << " ya existe.\n";
        return;
    }
    registrarEnlaceInterno(a, b);
    guardarDisco();
    cout << "Listo, conectamos " << a << " con " << b << ".\n";
}

void Grafo::removerEnlace(const string& a, const string& b) {
    if (!existeEnlace(a, b)) {
        cout << "No hay ninguna conexion entre ellos.\n";
        return;
    }

    auto& vecinosA = mapaConexiones[a];
    vecinosA.erase(remove(vecinosA.begin(), vecinosA.end(), b), vecinosA.end());

    auto& vecinosB = mapaConexiones[b];
    vecinosB.erase(remove(vecinosB.begin(), vecinosB.end(), a), vecinosB.end());

    guardarDisco();
    cout << "Quitamos la conexion de " << a << " a " << b << ".\n";
}

void Grafo::mostrarEstructura() const {
    if (registroVertices.empty()) {
        cout << "\nEl grafo esta vacio.\n";
        return;
    }

    cout << "\n--- Grafo actual ---\n";
    for (const string& v : registroVertices) {
        cout << v << " -> ";
        const auto& lista = mapaConexiones.at(v);
        if (lista.empty()) {
            cout << "(sin conexiones)";
        } else {
            for (size_t i = 0; i < lista.size(); i++) {
                cout << lista[i] << (i != lista.size() - 1 ? ", " : "");
            }
        }
        cout << "\n";
    }
    cout << "--------------------\n";
}

void Grafo::recorridoAncho(const string& origen) const {
    if (!existeVertice(origen)) {
        cout << "Ese vertice no esta en el grafo.\n";
        return;
    }

    map<string, bool> visitado;
    queue<string> cola;

    visitado[origen] = true;
    cola.push(origen);

    cout << "\nRecorrido BFS desde \"" << origen << "\": ";

    while (!cola.empty()) {
        string actual = cola.front();
        cola.pop();
        cout << actual << " ";

        for (const string& vecino : mapaConexiones.at(actual)) {
            if (!visitado[vecino]) {
                visitado[vecino] = true;
                cola.push(vecino);
            }
        }
    }
    cout << "\n";
}

void Grafo::ejecutarDfs(const string& v, map<string, bool>& marcas) const {
    marcas[v] = true;
    cout << v << " ";

    for (const string& vecino : mapaConexiones.at(v)) {
        if (!marcas[vecino]) {
            ejecutarDfs(vecino, marcas);
        }
    }
}

void Grafo::recorridoProfundo(const string& origen) const {
    if (!existeVertice(origen)) {
        cout << "Ese vertice no esta en el grafo.\n";
        return;
    }

    map<string, bool> marcas;
    cout << "\nRecorrido DFS desde \"" << origen << "\": ";
    ejecutarDfs(origen, marcas);
    cout << "\n";
}

bool Grafo::comprobarConexion(const string& a, const string& b) const {
    if (!existeVertice(a) || !existeVertice(b)) return false;
    if (a == b) return true;

    map<string, bool> visitado;
    queue<string> fila;

    visitado[a] = true;
    fila.push(a);

    while (!fila.empty()) {
        string actual = fila.front();
        fila.pop();

        if (actual == b) return true;

        for (const string& vec : mapaConexiones.at(actual)) {
            if (!visitado[vec]) {
                visitado[vec] = true;
                fila.push(vec);
            }
        }
    }
    return false;
}

void Grafo::guardarDisco() {
    ofstream out(nombreDoc);
    out << "{\n";
    for (size_t i = 0; i < registroVertices.size(); ++i) {
        string v = registroVertices[i];
        out << "  \"" << v << "\": [";
        const auto& lista = mapaConexiones.at(v);
        for (size_t j = 0; j < lista.size(); ++j) {
            out << "\"" << lista[j] << "\"";
            if (j != lista.size() - 1) out << ", ";
        }
        out << "]";
        if (i != registroVertices.size() - 1) out << ",";
        out << "\n";
    }
    out << "}\n";
    out.close();
}

void Grafo::cargarDisco() {
    ifstream in(nombreDoc);
    if (!in.is_open()) return;

    string contenido((istreambuf_iterator<char>(in)), istreambuf_iterator<char>());
    in.close();

    string llave = "";
    string valor = "";
    bool enComillas = false;
    bool enArreglo = false;
    bool leyendoLlave = true; 
    string cadenaActual = "";

    for (char c : contenido) {
        if (c == '"') {
            enComillas = !enComillas;
            if (!enComillas) {
                if (leyendoLlave) {
                    llave = cadenaActual;
                } else if (enArreglo) {
                    valor = cadenaActual;
                    if (!llave.empty() && !valor.empty()) {
                        registrarEnlaceInterno(llave, valor);
                    }
                }
                cadenaActual = "";
            }
            continue;
        }
        
        if (enComillas) {
            cadenaActual += c;
            continue;
        }

        if (c == ' ' || c == '\n' || c == '\r' || c == '\t') continue;

        if (c == ':') {
            leyendoLlave = false;
        } else if (c == '[') {
            enArreglo = true;
            if (!llave.empty()) {
                registrarVerticeInterno(llave); 
            }
        } else if (c == ']') {
            enArreglo = false;
            leyendoLlave = true;
            llave = "";
        }
    }
}