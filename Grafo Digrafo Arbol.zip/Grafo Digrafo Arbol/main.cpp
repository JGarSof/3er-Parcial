#include <iostream>
#include <string>
#include "Arbol.h"
#include "Digrafo.h"
#include "Grafo.h"

using namespace std;

void menuArbol() {
    Arbol miArbol("datos_arbol.json"); 
    int seleccion;
    string entradaUsuario;

    do {
        cout << "\n------------------------------------------------\n";
        cout << "SUBMENU: ARBOL BINARIO\n";
        cout << "1. Meter dato\n";
        cout << "2. Borrar dato\n";
        cout << "3. Buscar dato\n";
        cout << "4. Ver en Pre-orden\n";
        cout << "5. Ver en In-orden\n";
        cout << "6. Ver en Post-orden\n";
        cout << "7. Volver al panel principal\n";
        cout << "----------------------------------------------------\n";
        cout << "--Selecciona una alternativa: ";

        if (!(cin >> seleccion)) {
            cin.clear();
            cin.ignore(10000, '\n');
            continue;
        }

        switch (seleccion) {
            case 1:
                cout << "Dato a ingresar (valor o texto): ";
                cin >> entradaUsuario;
                miArbol.agregarDato(entradaUsuario);
                break;
            case 2:
                cout << "Dato a borrar: ";
                cin >> entradaUsuario;
                miArbol.quitarDato(entradaUsuario);
                break;
            case 3:
                cout << "Dato a buscar: ";
                cin >> entradaUsuario;
                if (miArbol.existeDato(entradaUsuario)) {
                    cout << "Si, '" << entradaUsuario << "' SI existe en el arbol.\n";
                } else {
                    cout << "No, '" << entradaUsuario << "' NO existe en la estructura.\n";
                }
                break;
            case 4:
                miArbol.imprimirPreOrden();
                break;
            case 5:
                miArbol.imprimirInOrden();
                break;
            case 6:
                miArbol.imprimirPostOrden();
                break;
            case 7:
                cout << "Saliendo del bloque de Arboles...\n";
                break;
            default:
                cout << "Alternativa incorrecta, intenta de nuevo.\n";
        }
    } while (seleccion != 7);
}

void menuDigrafo() {
    Digrafo miRed("red_datos.json");
    int seleccion;
    string v1, v2;

    do {
        cout << "\n------------------------------------------------\n";
        cout << "SUBMENU: DIGRAFO\n";
        cout << "1. Nuevo nodo\n";
        cout << "2. Eliminar nodo\n";
        cout << "3. Conectar nodos\n";
        cout << "4. Desconectar nodos\n";
        cout << "5. Ver digrafo\n";
        cout << "6. Ver mejor ruta\n";
        cout << "7. Volver al panel principal\n";
        cout << "----------------------------------------------------\n";
        cout << "--Selecciona una alternativa: ";

        if (!(cin >> seleccion)) {
            cin.clear();
            cin.ignore(10000, '\n');
            continue; 
        }

        switch (seleccion) {
            case 1:
                cout << "Nombre del nodo: ";
                cin >> v1;
                miRed.insertarVertice(v1);
                break;
            case 2:
                cout << "Nodo a borrar: ";
                cin >> v1;
                miRed.borrarVertice(v1);
                break;
            case 3:
                cout << "Nodo de origen: ";
                cin >> v1;
                cout << "Nodo de destino: ";
                cin >> v2;
                miRed.conectarVertices(v1, v2);
                break;
            case 4:
                cout << "Nodo de origen: ";
                cin >> v1;
                cout << "Nodo de destino: ";
                cin >> v2;
                miRed.desconectarVertices(v1, v2);
                break;
            case 5:
                miRed.imprimirEstructura();
                break;
            case 6:
                cout << "Punto de inicio: ";
                cin >> v1;
                cout << "Punto final: ";
                cin >> v2;
                miRed.trazarRuta(v1, v2);
                break;
            case 7:
                cout << "Saliendo del bloque de Digrafos...\n";
                break;
            default:
                cout << "Alternativa incorrecta, intenta de nuevo.\n";
        }
    } while (seleccion != 7);
}

void menuGrafo() {
    Grafo miGrafo("grafo.json");
    int opcion;
    string v, vA, vB;

    do {
        cout << "\n------------------------------------------------\n";
        cout << "SUBMENU: GRAFO\n";
        cout << "1. Nuevo nodo\n";
        cout << "2. Eliminar nodo\n";
        cout << "3. Conectar nodos\n";
        cout << "4. Desconectar nodos\n";
        cout << "5. Ver grafo\n";
        cout << "6. Recorrido BFS\n";
        cout << "7. Recorrido DFS\n";
        cout << "8. Verificar enlace\n";
        cout << "9. Volver al panel principal\n";
        cout << "----------------------------------------------------\n";
        cout << "--Selecciona una alternativa: ";

        if (!(cin >> opcion)) {
            cin.clear();
            cin.ignore(10000, '\n');
            continue;
        }

        switch (opcion) {
            case 1:
                cout << "Nombre del nodo: ";
                cin >> v;
                miGrafo.insertarVertice(v);
                break;
            case 2:
                cout << "Nodo a borrar: ";
                cin >> v;
                miGrafo.removerVertice(v);
                break;
            case 3:
                cout << "Primer nodo (origen): ";
                cin >> vA;
                cout << "Segundo nodo (destino): ";
                cin >> vB;
                miGrafo.insertarEnlace(vA, vB);
                break;
            case 4:
                cout << "Primer nodo (origen): ";
                cin >> vA;
                cout << "Segundo nodo (destino): ";
                cin >> vB;
                miGrafo.removerEnlace(vA, vB);
                break;
            case 5:
                miGrafo.mostrarEstructura();
                break;
            case 6:
                cout << "Inicio de BFS: ";
                cin >> v;
                miGrafo.recorridoAncho(v);
                break;
            case 7:
                cout << "Inicio de DFS: ";
                cin >> v;
                miGrafo.recorridoProfundo(v);
                break;
            case 8:
                cout << "Pon el primer nodo: ";
                cin >> vA;
                cout << "Pon el segundo nodo: ";
                cin >> vB;
                if (miGrafo.comprobarConexion(vA, vB)) {
                    cout << vA << " y " << vB << " SI se encuentran enlazados.\n";
                } else {
                    cout << vA << " y " << vB << " NO se encuentran enlazados.\n";
                }
                break;
            case 9:
                cout << "Saliendo del bloque de Grafos...\n";
                break;
            default:
                cout << "Alternativa incorrecta, intenta de nuevo.\n";
        }
    } while (opcion != 9);
}

int main() {
    int opcionEstructura;

    do {
        cout << "\n====================================================\n";
        cout << "          SISTEMA DE ARBOL GRAFO Y DIGRAFO     \n";
        cout << "====================================================\n";
        cout << "1. Usar  Arbol\n";
        cout << "2. Usar  Digrafo\n";
        cout << "3. Usar  Grafo\n";
        cout << "4. Salir del programa\n";
        cout << "====================================================\n";
        cout << "--Selecciona una opcion de (1-4): ";

        if (!(cin >> opcionEstructura)) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Seleccionar una de las 4 opciones existentes.\n";
            continue;
        }

        switch (opcionEstructura) {
            case 1:
                menuArbol();
                break;
            case 2:
                menuDigrafo();
                break;
            case 3:
                menuGrafo();
                break;
            case 4:
                cout << "\nSaliendo del programa.\n";
                break;
            default:
                cout << "Seleccionar una de las 4 opciones existentes.\n";
        }
    } while (opcionEstructura != 4);

    return 0;
}