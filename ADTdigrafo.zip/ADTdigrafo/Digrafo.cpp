#include "Digrafo.h"
#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>

using namespace std;


Digrafo::Digrafo(const string& archivo) : rutaDocumento(archivo) {
    recuperarDeDisco();
}


void Digrafo::registrarVerticeBase(const string& vertice) {
    if (redAdyacencia.find(vertice) == redAdyacencia.end()) {
        redAdyacencia[vertice] = vector<string>();
        listaVertices.push_back(vertice);
    }
}


void Digrafo::registrarEnlaceBase(const string& origen, const string& destino) {
    registrarVerticeBase(origen);
    registrarVerticeBase(destino);

    if (enlacePresente(origen, destino)) return;
    redAdyacencia[origen].push_back(destino); 
}

bool Digrafo::verticePresente(const string& vertice) const {
    return redAdyacencia.count(vertice) > 0;
}


bool Digrafo::enlacePresente(const string& origen, const string& destino) const {
    if (!verticePresente(origen)) return false;
    const auto& conexiones = redAdyacencia.at(origen);
    return find(conexiones.begin(), conexiones.end(), destino) != conexiones.end();
}


void Digrafo::insertarVertice(const string& vertice) {
    if (verticePresente(vertice)) {
        cout << "[Aviso] El vertice '" << vertice << "' ya se encuentra registrado.\n";
        return;
    }
    registrarVerticeBase(vertice);
    volcarADisco();
    cout << "[Exito] Vertice '" << vertice << "' agregado correctamente.\n";
}


void Digrafo::borrarVertice(const string& vertice) {
    if (!verticePresente(vertice)) {
        cout << "[Error] No se encontro el vertice '" << vertice << "'.\n";
        return;
    }

    
    for (auto& elemento : redAdyacencia) {
        auto& conexiones = elemento.second;
        conexiones.erase(remove(conexiones.begin(), conexiones.end(), vertice), conexiones.end());
    }

    redAdyacencia.erase(vertice);
    listaVertices.erase(remove(listaVertices.begin(), listaVertices.end(), vertice), listaVertices.end());

    volcarADisco();
    cout << "[Exito] Vertice '" << vertice << "' eliminado por completo.\n";
}


void Digrafo::conectarVertices(const string& origen, const string& destino) {
    if (enlacePresente(origen, destino)) {
        cout << "[Aviso] La conexion '" << origen << " => " << destino << "' ya esta activa.\n";
        return;
    }
    registrarEnlaceBase(origen, destino);
    volcarADisco();
    cout << "[Exito] Conexion '" << origen << " => " << destino << "' establecida.\n";
}


void Digrafo::desconectarVertices(const string& origen, const string& destino) {
    if (!enlacePresente(origen, destino)) {
        cout << "[Error] La conexion especificada no existe.\n";
        return;
    }

    auto& conexiones = redAdyacencia[origen];
    conexiones.erase(remove(conexiones.begin(), conexiones.end(), destino), conexiones.end());

    volcarADisco();
    cout << "[Exito] Conexion '" << origen << " => " << destino << "' destruida.\n";
}


void Digrafo::imprimirEstructura() const {
    if (listaVertices.empty()) {
        cout << "\n[Info] La red esta completamente vacia.\n";
        return;
    }

    cout << "\n================= MAPA DIGRAFO =================\n";
    for (const auto& v : listaVertices) {
        cout << "[ " << v << " ] se conecta con: ";
        const auto& conexiones = redAdyacencia.at(v);
        if (conexiones.empty()) {
            cout << "Ninguno";
        } else {
            for (size_t i = 0; i < conexiones.size(); ++i) {
                cout << conexiones[i] << (i < conexiones.size() - 1 ? " | " : "");
            }
        }
        cout << "\n";
    }
    cout << "================================================\n";
}


vector<string> Digrafo::calcularRuta(const string& inicio, const string& fin) const {
    vector<string> recorrido;
    if (!verticePresente(inicio) || !verticePresente(fin)) return recorrido;
    if (inicio == fin) {
        recorrido.push_back(inicio);
        return recorrido;
    }

    map<string, bool> rastreo;
    map<string, string> historialPadres;
    queue<string> frontera;

    rastreo[inicio] = true;
    frontera.push(inicio);
    bool objetivoAlcanzado = false;

    while (!frontera.empty() && !objetivoAlcanzado) {
        string nodoActual = frontera.front();
        frontera.pop();

        for (const string& adyacente : redAdyacencia.at(nodoActual)) {
            if (!rastreo[adyacente]) {
                rastreo[adyacente] = true;
                historialPadres[adyacente] = nodoActual;

                if (adyacente == fin) {
                    objetivoAlcanzado = true;
                    break;
                }
                frontera.push(adyacente);
            }
        }
    }

    if (!rastreo[fin]) return recorrido; 

    
    string paso = fin;
    while (paso != inicio) {
        recorrido.push_back(paso);
        paso = historialPadres[paso];
    }
    recorrido.push_back(inicio);
    reverse(recorrido.begin(), recorrido.end());
    return recorrido;
}

void Digrafo::trazarRuta(const string& inicio, const string& fin) const {
    if (!verticePresente(inicio) || !verticePresente(fin)) {
        cout << "[Error] Los vertices indicados no son validos.\n";
        return;
    }

    vector<string> recorrido = calcularRuta(inicio, fin);
    if (recorrido.empty()) {
        cout << "[Info] No hay comunicacion posible desde \"" << inicio << "\" hasta \"" << fin << "\".\n";
        return;
    }

    cout << ">> Ruta encontrada: ";
    for (size_t i = 0; i < recorrido.size(); ++i) {
        cout << recorrido[i] << (i < recorrido.size() - 1 ? " => " : "");
    }
    cout << "\n";
}


void Digrafo::volcarADisco() {
    ofstream salida(rutaDocumento);
    salida << "{\n";
    for (size_t i = 0; i < listaVertices.size(); ++i) {
        string v = listaVertices[i];
        salida << "  \"" << v << "\": [";
        const auto& conexiones = redAdyacencia.at(v);
        for (size_t j = 0; j < conexiones.size(); ++j) {
            salida << "\"" << conexiones[j] << "\"";
            if (j != conexiones.size() - 1) salida << ", ";
        }
        salida << "]";
        if (i != listaVertices.size() - 1) salida << ",";
        salida << "\n";
    }
    salida << "}\n";
    salida.close();
}


void Digrafo::recuperarDeDisco() {
    ifstream entrada(rutaDocumento);
    if (!entrada.is_open()) return;

    string contenido((istreambuf_iterator<char>(entrada)), istreambuf_iterator<char>());
    entrada.close();

    string llave = "";
    string valor = "";
    bool enComillas = false;
    bool enArreglo = false;
    bool leyendoLlave = true;
    string cadenaActual = "";

    for (char c : contenido) {
        if (c == '"') {
            enComillas = !enComillas;
            if (!enComillas) {
                if (leyendoLlave) {
                    llave = cadenaActual;
                } else if (enArreglo) {
                    valor = cadenaActual;
                    if (!llave.empty() && !valor.empty()) {
                        registrarEnlaceBase(llave, valor);
                    }
                }
                cadenaActual = "";
            }
            continue;
        }

        if (enComillas) {
            cadenaActual += c;
            continue;
        }

        if (c == ' ' || c == '\n' || c == '\r' || c == '\t') continue;

        if (c == ':') {
            leyendoLlave = false;
        } else if (c == '[') {
            enArreglo = true;
            if (!llave.empty()) {
                registrarVerticeBase(llave);
            }
        } else if (c == ']') {
            enArreglo = false;
            leyendoLlave = true;
            llave = "";
        }
    }
}
