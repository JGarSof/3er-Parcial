#include <iostream>
#include <string>
#include "Digrafo.h"

using namespace std;

int main() {
    // Instanciamos el ADT Digrafo
    Digrafo miRed("red_datos.json");
    int seleccion;
    string v1, v2;

    do {
        cout << "\n========================================\n";
        cout << "         PANEL DE ADT: DIGRAFO          \n";
        cout << "========================================\n";
        cout << "1. Registrar un nuevo nodo\n";
        cout << "2. Eliminar un nodo existente\n";
        cout << "3. Conectar nodos (Arco Dirigido)\n";
        cout << "4. Desconectar nodos\n";
        cout << "5. Visualizar estructura del Digrafo\n";
        cout << "6. Trazar mejor ruta (BFS)\n";
        cout << "7. Salir del sistema\n";
        cout << "========================================\n";
        cout << "-- Selecciona una alternativa: ";

        if (!(cin >> seleccion)) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Entrada no valida. Intenta de nuevo.\n";
            continue;
        }

        switch (seleccion) {
            case 1:
                cout << "Introduce el nombre del nodo: ";
                cin >> v1;
                miRed.insertarVertice(v1);
                break;
            case 2:
                cout << "Introduce el nodo a borrar: ";
                cin >> v1;
                miRed.borrarVertice(v1);
                break;
            case 3:
                cout << "Nodo de origen (sale la flecha): ";
                cin >> v1;
                cout << "Nodo de destino (recibe la flecha): ";
                cin >> v2;
                miRed.conectarVertices(v1, v2);
                break;
            case 4:
                cout << "Nodo de origen: ";
                cin >> v1;
                cout << "Nodo de destino: ";
                cin >> v2;
                miRed.desconectarVertices(v1, v2);
                break;
            case 5:
                miRed.imprimirEstructura();
                break;
            case 6:
                cout << "Punto de inicio: ";
                cin >> v1;
                cout << "Punto final: ";
                cin >> v2;
                miRed.trazarRuta(v1, v2);
                break;
            case 7:
                cout << "\nCerrando el sistema del ADT Digrafo. �Hasta luego!\n";
                break;
            default:
                cout << "Alternativa incorrecta, intenta con un numero del 1 al 7.\n";
        }
    } while (seleccion != 7);

    return 0;
}
