#ifndef DIGRAFO_H
#define DIGRAFO_H

#include <string>
#include <vector>
#include <map>


// ADT DIGRAFO (Tipo de Dato Abstracto)

class Digrafo {
private:
  
    std::map<std::string, std::vector<std::string>> redAdyacencia;
    std::vector<std::string> listaVertices;                       
    std::string rutaDocumento;                                    

    
    void registrarVerticeBase(const std::string& vertice);
    void registrarEnlaceBase(const std::string& origen, const std::string& destino);
    void volcarADisco();
    void recuperarDeDisco();
    std::vector<std::string> calcularRuta(const std::string& inicio, const std::string& fin) const;

public:
    
    Digrafo(const std::string& archivo = "red_datos.json");

  
    bool verticePresente(const std::string& vertice) const;
    bool enlacePresente(const std::string& origen, const std::string& destino) const;

   
    void insertarVertice(const std::string& vertice);
    void borrarVertice(const std::string& vertice);
    void conectarVertices(const std::string& origen, const std::string& destino);
    void desconectarVertices(const std::string& origen, const std::string& destino);

    
    void imprimirEstructura() const;
    void trazarRuta(const std::string& inicio, const std::string& fin) const;
};

#endif
